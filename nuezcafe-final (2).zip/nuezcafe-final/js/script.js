document.fonts.ready.then(() => {
  document.body.style.visibility = 'visible';
});
document.body.style.visibility = 'hidden';
